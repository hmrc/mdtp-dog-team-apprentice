Node.js resources and tutorials
==============================

A collection of blog posts, online tutorials and other resources on the topic of node.js and javascript on the server.

Beginner
--------

* [A basic HTTP web server](https://www.sitepoint.com/creating-a-http-server-in-node-js/)
* [Real time web apps with Websockets](https://www.youtube.com/watch?v=bjULmG8fqc8). Great for understanding how to build chat apps and similar.
