Amazon Web Services
==================

Tutorials, blog posts and other resources about Amazon Web Services and the cloud in general.

Beginners
---------

AWS Concepts Course on Udemy (free) - very basic https://www.udemy.com/aws-concepts/learn/v4/overview
AWS Essentials Course on Udemy (freed) https://www.udemy.com/aws-essentials/learn/v4/overview
